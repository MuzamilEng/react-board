import React from "react";
import Whiteboard from "../src/WhiteBoard";

export default function Home() {
  return (
    <main>
      <Whiteboard />
    </main>
  );
}
