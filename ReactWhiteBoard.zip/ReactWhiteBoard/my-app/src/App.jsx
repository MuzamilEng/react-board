import React, { useEffect, useState } from 'react'
import WhiteBoard from './WhiteBoard'
import {Routes, Route} from 'react-router-dom'
import Dashboard from './Dashboard'
const App = () => {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/board/:id" element={<WhiteBoard />} />
      </Routes>
    </div>
  )
}

export default App