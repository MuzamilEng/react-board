import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useGlobalContext } from './context/UserContext'


import { configureLiveblocks } from "../liveblocks.config"; // Adjust the path as needed

// Your dashboard component continues here...

const Dashboard = () => {
    const [boards, setBoards] = useState([])
    const {setBoardId, boardId} = useGlobalContext()
    const navigate = useNavigate();
    const [boardTitle, setBoardTitle] = useState('')
    const fetchAllboards = async () => {
        try {
        const boards = await fetch('http://localhost:5000/getAllboards');
        const data = await boards.json();
        setBoards(data);
        } catch (error) {
            console.error('Error during board retrieval:', error);
        }
    }

    useEffect(() => {
        fetchAllboards()
    }, []);

    const createBoard = async (e) => {
        e.preventDefault();
        try {
            const board = await fetch('http://localhost:5000/create-board', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ boardTitle }),
            });
            const data = await board.json();
            setBoards([...boards, data]);
        } catch (error) {
            console.error('Error during board creation:', error);
        }
    }

    const handleBoardClick = (boardId) =>{
        setBoardId(boardId);
        localStorage.setItem('boardId', boardId);
        navigate(`/board/${boardId}`)
        console.log(boardId)
    }

    const {
        suspense: {
          RoomProvider,
          useCanRedo,
          useCanUndo,
          useHistory,
          useMutation,
          useOthers,
          useOthersMapped,
          useOthersConnectionIds,
          useOther,
          useRoom,
          useSelf,
          useStorage,
          useUpdateMyPresence,
        },
      } = configureLiveblocks(boardId);

  return (
    <div>
      <h1>Dashboard</h1>
      {boards && boards?.map(board => <div className='text-4xl bg-blue-600 p-32' onClick={()=> handleBoardClick(board?._id)} key={board?._id}>{board?.boardTitle}</div>)}

      <form onSubmit={createBoard} className='w-[50vw] p-5 border-2 '>
        <label htmlFor="boardTitle" className='text-2xl'>Board Title</label>
        <input type="text" id="boardTitle" value={boardTitle} onChange={(e)=> setBoardTitle(e.target.value)} name='boardTitle' className='w-[50vw] border-2 border-blue-600' />
        <button type='submit' className='p-4 bg-blue-300 '>Create</button>
      </form>

    </div>
  )
}

export default Dashboard