import React, { createContext, useContext, useState } from 'react';

export const UserContext = createContext(); // Export UserContext

export const useGlobalContext = () => useContext(UserContext);

export const UserProvider = ({ children }) => {

  const [boardId, setBoardId] = useState(null);

  return (
    <UserContext.Provider value={{ boardId, setBoardId }}>
      {children}
    </UserContext.Provider>
  );
};
