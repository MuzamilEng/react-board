const express = require('express');
const app = express();
const path = require('path');


require('dotenv').config({ path: '.env' });
const connectDB = require('./db/connect');
const cors = require('cors');
const board = require('./routes/board');

const port = 5000;

// Middleware
app.use(cors({ origin: '*' }));
app.use(express.json());

// Routes

app.use('/', board);

app.post("/api/liveblocks-auth", async (req, res) => {
  console.log('request');
  const session = liveblocks.prepareSession(
    `user-${Math.floor(Math.random() * 10)}`
  );
  session.allow(`liveblocks:examples:*`, session.FULL_ACCESS);

  const { status, body } = await session.authorize();
  const data = JSON.parse(body);
  console.log(data, "data");

  res.status(status).json(data); // Use res.json for cleaner JSON response
  res.end(); // Close the connection
});


const start = async () => {
  try {
    await connectDB(process.env.URI);
    app.listen(port, () =>
      console.log(`Server is listening on port ${port}...`)
    );
  } catch (error) {
    console.log(error);
  }
};

start();
